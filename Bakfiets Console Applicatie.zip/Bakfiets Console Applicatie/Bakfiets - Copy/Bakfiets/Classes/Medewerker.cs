﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bakfiets
{

    public class Medewerker
    {
        private int medewerkernummer;
        private string achternaam;
        private string voornaam;
        private DateTime datum_in_dienst;

        

        public int Medewerkernummer
        {
            set { medewerkernummer = value; }
            get { return medewerkernummer; }
        }
       

        public string Achternaam
        {
            set { achternaam = value; }
            get { return achternaam; }
        }
        public string Voornaam
        {
            set { voornaam = value; }
            get { return voornaam; }
        }
        public DateTime Datum_in_dienst
        {
            set { datum_in_dienst = value; }
            get { return datum_in_dienst; }
        }

        

        public Medewerker (int medewerkernummer, string achternaam, string voornaam, DateTime datum_in_dienst)
        {
            this.medewerkernummer = medewerkernummer;
            this.achternaam = achternaam;
            this.voornaam = voornaam;
            this.datum_in_dienst = datum_in_dienst;
        }

        public Medewerker()
        {

        }

        public Medewerker(int medewerkernummer)
        {
            this.medewerkernummer = medewerkernummer;
        }
    }

}
