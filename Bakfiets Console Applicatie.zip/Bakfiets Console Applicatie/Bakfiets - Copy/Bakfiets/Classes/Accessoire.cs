﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bakfiets
{
    public class Accessoire
    {
        private int accessoirenummer;
        private string naam;
        private decimal huurprijs;

        public int Accessoirenummer
        {
            set { accessoirenummer = value; }
            get { return accessoirenummer; }
        }

        public string Naam
        {
            set { naam = value; }
            get { return naam; }
        }

        public decimal Huurprijs
        {
            set { huurprijs = value; }
            get { return huurprijs; }
        }

        public Accessoire()
        {

        }

        public Accessoire(string naam, decimal huurprijs)
        {
            this.naam = naam;
            this.huurprijs = huurprijs;
        }


        public Accessoire(int accessoirenummer, string naam, decimal huurprijs)
        {
            this.accessoirenummer = accessoirenummer;
            this.naam = naam;
            this.huurprijs = huurprijs;
        }



    }


}
