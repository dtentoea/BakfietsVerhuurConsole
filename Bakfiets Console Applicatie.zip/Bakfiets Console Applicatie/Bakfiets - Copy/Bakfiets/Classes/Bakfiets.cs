﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bakfiets
{
    public class Bakfiets
    {
        private int bakfietsnummer;
        private string naam;
        private string type;
        private decimal huurprijs;
        private int aantal;
        private int aantal_verhuurd;

        public int Bakfietsnummer
        {
            set { bakfietsnummer = value; }
            get { return bakfietsnummer; }
        }

        public string Naam
        {
            set { naam = value; }
            get { return naam; }
        }

        public string Type
        {
            set { type = value; }
            get { return type; }
        }

        public decimal Huurprijs
        {
            set { huurprijs = value; }
            get { return huurprijs; }
        }

        public int Aantal
        {
            set { aantal = value; }
            get { return aantal; }
        }
        public int Aantal_verhuurd
        {
            set { aantal_verhuurd = value; }
            get { return aantal_verhuurd; }
        }

        public Bakfiets(int bakfietsnummer, string naam, string type, decimal huurprijs, int aantal, int aantal_verhuurd)
        {
            this.bakfietsnummer = bakfietsnummer;
            this.naam = naam;
            this.type = type;
            this.huurprijs = huurprijs;
            this.aantal = aantal;
            this.aantal_verhuurd = aantal_verhuurd;
        }

        public Bakfiets(int bakfietsnummer)
        {
            this.bakfietsnummer = bakfietsnummer;
        }

        public Bakfiets()
        {

        }

        public Bakfiets(int bakfietsnummer, decimal huurprijs)
        {
            this.bakfietsnummer = bakfietsnummer;
            this.huurprijs = huurprijs;
        }

        public Bakfiets(string naam, string type, decimal huurprijs, int aantal, int aantal_verhuurd)
        {
            this.naam = naam;
            this.type = type;
            this.huurprijs = huurprijs;
            this.aantal = aantal;
            this.aantal_verhuurd = aantal_verhuurd;
        }

        public Bakfiets(decimal huurprijs)
        {
            this.huurprijs = huurprijs;
        }
    }


    
}
