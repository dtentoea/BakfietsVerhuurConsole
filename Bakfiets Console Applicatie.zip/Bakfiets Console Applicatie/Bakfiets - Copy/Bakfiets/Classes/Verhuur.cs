﻿using System;
using System.Collections.Generic;

namespace Bakfiets
{
    public class Verhuur
    {
        private int verhuurnummer;
        private DateTime verhuurdatum;
        private Bakfiets bakfietsnummer;
        private int aantal_dagen;
        private decimal huurprijstotaal;
        private Klant klantnummer;
        public Medewerker medewerkernummer;
        

        public int Verhuurnummer
        {
            set { verhuurnummer = value; }
            get { return verhuurnummer; }
        }

        public DateTime Verhuurdatum
        {
            set { verhuurdatum = value; }
            get { return verhuurdatum; }
        }
        public int Aantal_dagen
        {
            set { aantal_dagen = value; }
            get { return aantal_dagen; }
        }
        public decimal Huurprijstotaal
        {
            set { huurprijstotaal = value; }
            get { return huurprijstotaal; }
        }

        public Bakfiets Bakfietsnummer
        {
            set { bakfietsnummer = value; }
            get { return bakfietsnummer; }
        }


        public Klant Klantnummer
        {
            set { klantnummer = value; }
            get { return klantnummer; }
        }

        public Medewerker Medewerkernummer
        {
            set { medewerkernummer = value; }
            get { return medewerkernummer; }
        }



        public Verhuur(int verhuurnummer, DateTime verhuurdatum, Bakfiets bNummer, int aantal_dagen, decimal huurprijstotaal, Klant kNummer, Medewerker mNummer)
        {
            this.verhuurnummer = verhuurnummer;
            this.verhuurdatum = verhuurdatum;
            this.aantal_dagen = aantal_dagen;
            this.huurprijstotaal = huurprijstotaal;
            this.bakfietsnummer = bNummer;
            this.klantnummer = kNummer;
            this.medewerkernummer = mNummer;
        }





        public Verhuur()
        {

        }

    }


}
