﻿using System;
using System.Collections.Generic;

namespace Bakfiets
{
    class Program
    {
        static void Main(string[] args)
        {


            bool start = false;
            Yellow("Welkom bij Van der Binckes Bakfietsen verhuur!");
            Console.WriteLine();


                do
                {
                    //Console.Clear();
                    Console.WriteLine();
                    Yellow("Maak je keuze: (O) Overzicht, (A) Aanpassen, (B) Bestellen");
                    string keuze = Console.ReadLine();

                    // NIVEAU 1 
                    if (keuze == "o")
                    {
                        Console.Clear();
                        Yellow("Maak je keuze: (M) Mederwerker, (K) Klanten, (I) Inventaris, (V) Verhuur, (T) Terug)");
                        Console.WriteLine();
                        string keuzeO = Console.ReadLine();
                        Console.WriteLine();

                        // NIVEAU 2 
                        if (keuzeO == "m")
                        {
                            PrintAllMedewerkers();
                        }

                        if (keuzeO == "k")
                        {
                            PrintAllKlanten();
                        }

                        if (keuzeO == "i")
                        {
                            PrintAllBakfietsen();
                            Console.WriteLine();
                            PrintAllAccessoires();
                        }

                        if (keuzeO == "v")
                        {
                            PrintAllVerhuringen();
                        }

                        if (keuzeO == "t")
                        {
                            start = false;
                        }

                    }



                    // NIVEAU 1    OPTIE AANPASSEN 
                    if (keuze == "a")
                    {
                        Console.Clear();
                        Yellow("Maak een keuze: (A) Aanpassen, (V) Verwijderen, (T) Toevoegen");
                        string keuzeA = Console.ReadLine();


                        // NIVEAU 2   AANPASSEN
                        if (keuzeA == "a")
                        {
                            Yellow("Wat wilt u aanpassen? :  (k) klant,  (m) medewerker, (b) bakfiets, (a) accessoire, (t) Terug");
                            string keuzeA1 = Console.ReadLine();

                            if (keuzeA1 == "k")
                            {
                                KlantenConnect klantConn = new KlantenConnect();
                                PrintAllKlanten();
                                Console.WriteLine();

                                Klant klant = new Klant();

                                Yellow("Welke klant wilt u aanpassen? Voer het klantnummer in");
                                klant.Klantnummer = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Wat is de achternaam van de klant?");
                                klant.Naam = Console.ReadLine();

                                Console.WriteLine("Wat is de voornaam van de klant?");
                                klant.Voornaam = Console.ReadLine();

                                Console.WriteLine("Wat is de postcode van de klant?");
                                klant.Postcode = Console.ReadLine();

                                Console.WriteLine("Wat is het huisnummer van de klant?");
                                klant.Huisnummer = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("huisnummer toevoeging?");
                                klant.Huisnummer_toevoeging = Console.ReadLine();

                                Console.WriteLine("opmerkingen?");
                                klant.Opmerkingen = Console.ReadLine();

                                klantConn.AanpassenKlant(klant);

                            }
                            if (keuzeA1 == "m")
                            {
                                MedewerkersConnect mwConn = new MedewerkersConnect();
                                PrintAllMedewerkers();
                                Console.WriteLine();

                                Medewerker medewerker = new Medewerker();

                                Console.WriteLine("Welk nummer wil je aanpassen");
                                medewerker.Medewerkernummer = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Wat is de achternaam van de medewerker?");
                                medewerker.Achternaam = Console.ReadLine();

                                Console.WriteLine("Wat is de voornaam van de medewerker?");
                                medewerker.Voornaam = Console.ReadLine();

                                Console.WriteLine("Wat is de datum van dienst werk?");
                                medewerker.Datum_in_dienst = Convert.ToDateTime(Console.ReadLine());

                                mwConn.AanpassenMedewerker(medewerker);
                            }
                            if (keuzeA1 == "b")
                            {
                                BakfietsenConnect bkConn = new BakfietsenConnect();
                                PrintAllBakfietsen();
                                Console.WriteLine();

                                Bakfiets bakfiets = new Bakfiets();

                                Console.WriteLine("Welk nummer wil je aanpassen?");
                                bakfiets.Bakfietsnummer = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Wat is de naam van de bakfiets?");
                                bakfiets.Naam = Console.ReadLine();

                                Console.WriteLine("Wat is het type van de bakfiets?");
                                bakfiets.Type = Console.ReadLine();

                                Console.WriteLine("Wat is de huurprijs van de bakfiets?");
                                bakfiets.Huurprijs = Convert.ToDecimal(Console.ReadLine());

                                Console.WriteLine("hoeveel bakfietsen in  het inventaris?");
                                bakfiets.Aantal = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Hoeveel bakfietsen zijn er verhuurd?");
                                bakfiets.Aantal_verhuurd = Convert.ToInt32(Console.ReadLine());

                                bkConn.AanpassenBakfiets(bakfiets);
                            }
                            if (keuzeA1 == "a")
                            {
                                AccessoiresConnect accConn = new AccessoiresConnect();
                                PrintAllAccessoires();
                                Console.WriteLine();

                                Accessoire accessoire = new Accessoire();

                                Console.WriteLine("Welk nummer wil je aanpassen");
                                accessoire.Accessoirenummer = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Wat is de naam van de accessoire?");
                                accessoire.Naam = Console.ReadLine();

                                Console.WriteLine("Wat is de huurprijs van de accessoire?");
                                accessoire.Huurprijs = Convert.ToDecimal(Console.ReadLine());

                                accConn.AanpassenAccessoire(accessoire);
                            }
                            if (keuzeA1 == "t")
                            {
                                start = false;
                            }
                        }


                        // NIVEAU 2    VERWIJDEREN UIT DATABASE 
                        if (keuzeA == "v")
                        {
                            Yellow("Wat wilt u verwijderen? :  (k) klant,  (m) medewerker, (b) bakfiets, (a) accessoire, (t) Terug");
                            string keuzeA2 = Console.ReadLine();


                            if (keuzeA2 == "k")
                            {
                                KlantenConnect klantconn = new KlantenConnect();
                                Klant klant = new Klant();

                                PrintAllKlanten();
                                Console.WriteLine();
                                Yellow("Welke klant wilt u verwijderen? Voer het klantnummer in");

                                klant.Klantnummer = Convert.ToInt32(Console.ReadLine());

                                klantconn.VerwijderKlant(klant);
                            }
                            if (keuzeA2 == "m")
                            {
                                MedewerkersConnect mwConn = new MedewerkersConnect();
                                PrintAllMedewerkers();
                                Console.WriteLine();

                                Medewerker medewerker = new Medewerker();

                                Console.WriteLine("Welk nummer wil je verwijderen?");
                                medewerker.Medewerkernummer = Convert.ToInt32(Console.ReadLine());

                                mwConn.VerwijderenMedewerker(medewerker);
                            }
                            if (keuzeA2 == "b")
                            {
                                BakfietsenConnect bkConn = new BakfietsenConnect();
                                PrintAllBakfietsen();
                                Console.WriteLine();

                                Bakfiets bakfiets = new Bakfiets();

                                Console.WriteLine("Welk nummer wil je verwijderen");
                                bakfiets.Bakfietsnummer = Convert.ToInt32(Console.ReadLine());

                                bkConn.VerwijderenBakfiets(bakfiets);

                            }
                            if (keuzeA2 == "a")
                            {
                                AccessoiresConnect accConn = new AccessoiresConnect();
                                PrintAllAccessoires();
                                Console.WriteLine();

                                Accessoire accessoire = new Accessoire();

                                Console.WriteLine("Welk nummer wil je verwijderen");
                                accessoire.Accessoirenummer = Convert.ToInt32(Console.ReadLine());

                                accConn.VerwijderenAccessoire(accessoire);
                            }
                            if (keuzeA2 == "t")
                            {
                                start = false;
                            }
                        }

                        // NIVEAU 2    TOEVOEGEN AAN DATABASE 
                        if (keuzeA == "t")
                        {
                            Yellow("Wat wilt u toevoegen? :  (k) klant,  (m) medewerker, (b) bakfiets, (a) accessoire, (t) Terug");
                            string keuzeA3 = Console.ReadLine();

                            if (keuzeA3 == "k")
                            {
                                NieuweKlant();

                            }
                            if (keuzeA3 == "m")
                            {
                                MedewerkersConnect mwConn = new MedewerkersConnect();
                                PrintAllMedewerkers();
                                Console.WriteLine();

                                Medewerker medewerker = new Medewerker();

                                Console.WriteLine("Wat is de achternaam van de medewerker?");
                                medewerker.Achternaam = Console.ReadLine();

                                Console.WriteLine("Wat is de voornaam van de medewerker?");
                                medewerker.Voornaam = Console.ReadLine();

                                Console.WriteLine("Wat is de datum van dienst werk?");
                                medewerker.Datum_in_dienst = Convert.ToDateTime(Console.ReadLine());

                                mwConn.ToevoegenMedewerker(medewerker);
                            }
                            if (keuzeA3 == "b")
                            {
                                BakfietsenConnect bkConn = new BakfietsenConnect();
                                PrintAllBakfietsen();
                                Console.WriteLine();

                                Bakfiets bakfietsnieuw = new Bakfiets();

                                Console.WriteLine("Wat is de naam van de bakfiets?");
                                bakfietsnieuw.Naam = Console.ReadLine();

                                Console.WriteLine("Wat is het type van de bakfiets?");
                                bakfietsnieuw.Type = Console.ReadLine();

                                Console.WriteLine("Wat is de huurprijs van de bakfiets?");
                                bakfietsnieuw.Huurprijs = Convert.ToDecimal(Console.ReadLine());

                                Console.WriteLine("hoeveel bakfietsen in  het inventaris?");
                                bakfietsnieuw.Aantal = Convert.ToInt32(Console.ReadLine());

                                Console.WriteLine("Hoeveel bakfietsen zijn er verhuurd?");
                                bakfietsnieuw.Aantal_verhuurd = Convert.ToInt32(Console.ReadLine());

                                bkConn.ToevoegenBakfiets(bakfietsnieuw);
                            }
                            if (keuzeA3 == "a")
                            {
                                AccessoiresConnect accConn = new AccessoiresConnect();
                                PrintAllAccessoires();
                                Console.WriteLine();

                                Accessoire accessoirenieuw = new Accessoire();

                                Console.WriteLine("Wat is de naam van de accessoire?");
                                accessoirenieuw.Naam = Console.ReadLine();

                                Console.WriteLine("Wat is de huurprijs van de accessoire?");
                                accessoirenieuw.Huurprijs = Convert.ToDecimal(Console.ReadLine());

                                accConn.ToevoegenAccessoire(accessoirenieuw);
                            }
                            if (keuzeA3 == "t")
                            {
                                start = false;
                            }
                        }

                    }

                    // NIVEAU 1   OPTIE BESTELLEN 

                    if (keuze == "b")
                    {
                        Console.Clear();
                        Yellow("Is het voor een bestaande of nieuwe klant?  (B) Bestaan, (N) Nieuwe, (t)Terug");
                        string keuzeB = Console.ReadLine();


                        // NIVEAU 2    
                        if (keuzeB == "b")
                        {
                            VerhuurConnect vhConn = new VerhuurConnect();
                            BakfietsenConnect bkConn = new BakfietsenConnect();
                            Verhuur verhuurnieuw = new Verhuur();


                            PrintAllKlanten();
                            Console.WriteLine();
                            Yellow("Kies een klantnummer:");
                            verhuurnieuw.Klantnummer = new Klant();
                            verhuurnieuw.Klantnummer.Klantnummer = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();

                            PrintAllBakfietsen();
                            Console.WriteLine();
                            Yellow("Kies een bakfiets");
                            verhuurnieuw.Bakfietsnummer = new Bakfiets();
                            verhuurnieuw.Bakfietsnummer.Bakfietsnummer = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();



                            Yellow("Hoeveel dagen wilt de klant huren?");
                            verhuurnieuw.Aantal_dagen = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();

                            Yellow("Vanaf welke datumw wil de klant huren?");
                            verhuurnieuw.Verhuurdatum = Convert.ToDateTime(Console.ReadLine());


                            Console.WriteLine();
                            Console.WriteLine();
                            PrintAllMedewerkers();
                            Console.WriteLine();
                            Yellow("Vul nu je medewerkernummer in");
                            verhuurnieuw.medewerkernummer = new Medewerker();
                            verhuurnieuw.medewerkernummer.Medewerkernummer = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();

                            Bakfiets nieuwe = bkConn.GetBakfiets(verhuurnieuw.Bakfietsnummer.Bakfietsnummer);

                            verhuurnieuw.Huurprijstotaal = nieuwe.Huurprijs * verhuurnieuw.Aantal_dagen;



                            Console.WriteLine(Convert.ToString("Totaal prijs is: " + verhuurnieuw.Huurprijstotaal));

                            vhConn.ToevoegenVerhuur(verhuurnieuw);

                            Console.ReadLine();

                            Yellow("De Bestelling is ingevoerd!");

                            Console.ReadLine();
                        }

                        // NIVEAU 2    
                        if (keuzeB == "n")
                        {
                            NieuweKlant();

                            VerhuurConnect vhConn = new VerhuurConnect();
                            BakfietsenConnect bkConn = new BakfietsenConnect();
                            Verhuur verhuurnieuw = new Verhuur();


                            PrintAllKlanten();
                            Console.WriteLine();
                            Yellow("Kies een klantnummer:");
                            verhuurnieuw.Klantnummer = new Klant();
                            verhuurnieuw.Klantnummer.Klantnummer = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();

                            PrintAllBakfietsen();
                            Console.WriteLine();
                            Yellow("Kies een bakfiets");
                            verhuurnieuw.Bakfietsnummer = new Bakfiets();
                            verhuurnieuw.Bakfietsnummer.Bakfietsnummer = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();



                            Yellow("Hoeveel dagen wilt de klant huren?");
                            verhuurnieuw.Aantal_dagen = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();

                            Yellow("Vanaf welke datumw wil de klant huren?");
                            verhuurnieuw.Verhuurdatum = Convert.ToDateTime(Console.ReadLine());


                            Console.WriteLine();
                            Console.WriteLine();
                            PrintAllMedewerkers();
                            Console.WriteLine();
                            Yellow("Vul nu je medewerkernummer in");
                            verhuurnieuw.medewerkernummer = new Medewerker();
                            verhuurnieuw.medewerkernummer.Medewerkernummer = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine();
                            Console.WriteLine();

                            Bakfiets nieuwe = bkConn.GetBakfiets(verhuurnieuw.Bakfietsnummer.Bakfietsnummer);

                            verhuurnieuw.Huurprijstotaal = nieuwe.Huurprijs * verhuurnieuw.Aantal_dagen;



                            Console.WriteLine(Convert.ToString("Totaal prijs is: " + verhuurnieuw.Huurprijstotaal));

                            Console.ReadLine();

                            vhConn.ToevoegenVerhuur(verhuurnieuw);


                            Yellow("De Bestelling is ingevoerd!");

                            Console.ReadLine();
                        }

                        // NIVEAU 2    TERUG 
                        if (keuzeB == "t")
                        {
                            start = false;
                        }
                    }


                } while (!start);















            // FUNCTION AREA 


            static void Yellow(string value)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(value.PadRight(Console.WindowWidth - 1));
                Console.ResetColor();
            }


            static void PrintAllKlanten()
            {
                KlantenConnect klantCon = new KlantenConnect();
                List<Klant> klanten = klantCon.GetKlanten();
                Yellow("-- Overzicht Klanten --");
                foreach (Klant k in klanten)
                {
                    Console.WriteLine(k.Klantnummer + " " + k.Naam + " " + k.Voornaam + " " + k.Postcode + " " + k.Huisnummer + " " + k.Huisnummer_toevoeging + " " + k.Opmerkingen);
                }
            }

            static void PrintAllBakfietsen()
            {
                BakfietsenConnect bakCon = new BakfietsenConnect();
                List<Bakfiets> bakfietsen = bakCon.GetBakfietsen();
                Yellow("-- Overzicht Bakfiets --");
                foreach (Bakfiets b in bakfietsen)
                {
                    Console.WriteLine(b.Bakfietsnummer + " " + b.Naam + " " + b.Type + " " + b.Huurprijs + " " + b.Aantal + " " + b.Aantal_verhuurd);
                }
            }



            static void PrintAllAccessoires()
            {
                AccessoiresConnect accCon = new AccessoiresConnect();
                List<Accessoire> accessoires = accCon.GetAccessoires();
                Yellow("-- Overzicht Accessoires --");
                foreach (Accessoire a in accessoires)
                {
                    Console.WriteLine(a.Accessoirenummer + " " + a.Naam + " " + a.Huurprijs);
                }
            }

            static void PrintAllMedewerkers()
            {
                MedewerkersConnect mkCon = new MedewerkersConnect();
                List<Medewerker> medewerkers = mkCon.GetMedewerkers();
                Yellow("-- Overzicht Medewerkers --");
                foreach (Medewerker m in medewerkers)
                {
                    Console.WriteLine(m.Medewerkernummer + " " + m.Achternaam + " " + m.Voornaam + " " + m.Datum_in_dienst.ToString("yyyy-MM-dd"));
                }
            }

            static void PrintAllVerhuringen()
            {
                VerhuurConnect vhCon = new VerhuurConnect();
                List<Verhuur> verhuringen = vhCon.GetVerhuringen();
                Yellow("-- Overzicht Verhuringen --");
                foreach (Verhuur v in verhuringen)
                {
                    Console.WriteLine(v.Verhuurnummer + " " + v.Verhuurdatum.ToString("yyyy-MM-dd") + " " + v.Bakfietsnummer.Bakfietsnummer + " " + v.Aantal_dagen + " " + v.Huurprijstotaal + " " + v.Klantnummer.Klantnummer + " " + v.Medewerkernummer.Medewerkernummer);
                }
            }

            static void NieuweKlant()
            {
                KlantenConnect klantcon = new KlantenConnect();
                Klant nieuweKlant = new Klant();


                Console.WriteLine("Wat is de achternaam van de klant?");
                nieuweKlant.Naam = Console.ReadLine();

                Console.WriteLine("Wat is de voornaam van de klant?");
                nieuweKlant.Voornaam = Console.ReadLine();

                Console.WriteLine("Wat is de postcode van de klant?");
                nieuweKlant.Postcode = Console.ReadLine();

                Console.WriteLine("Wat is het huisnummer van de klant?");

                nieuweKlant.Huisnummer = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Huisnummer toevoeging?");
                nieuweKlant.Huisnummer_toevoeging = Console.ReadLine();

                Console.WriteLine("opmerkingen?");
                nieuweKlant.Opmerkingen = Console.ReadLine();

                klantcon.ToevoegenKlant(nieuweKlant);
            }



        }



    }

}
