﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace Bakfiets
{
    public class AccessoiresConnect
    {
        private string connString = string.Format("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
        private MySqlConnection connection = null;

        public bool IsConnect()
        {
            if (connection == null)
            {
                connection = new MySqlConnection(connString);
                connection.Open();
            }
            return true;
        }

        public List<Accessoire> GetAccessoires()
        {
            List<Accessoire> accessoireLijst = new List<Accessoire>();
            if (IsConnect())
            {
                string query = "SELECT * FROM accessoire";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int accessoirenummer = reader.GetInt32("accessoirenummer");
                    string naam = reader.GetString("naam");
                    decimal prijs = reader.GetDecimal("huurprijs");
                    Accessoire acc = new Accessoire(accessoirenummer, naam, prijs);
                    accessoireLijst.Add(acc);
                }
                reader.Close();
                Close();
            }
            return accessoireLijst;
        }

        public Accessoire GetAccessoire(int nummer)
        {
            Accessoire acc = null; 
            if (IsConnect())
            {
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM accessoire" + "WHERE accessoirenummer=@accessoirenummer", connection);
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@accessoirenummer", nummer);
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    int accessoirenummer = reader.GetInt32("accessoirenummer");
                    string naam = reader.GetString("naam");
                    decimal prijs = reader.GetDecimal("huurprijs");
                    acc = new Accessoire(accessoirenummer, naam, prijs);
                }
                reader.Close();
                Close();
            }
            return acc;
        }

        public Accessoire AanpassenAccessoire(Accessoire accessoire)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "UPDATE accessoire SET naam = '" + accessoire.Naam + "', huurprijs = '" + accessoire.Huurprijs + "' WHERE accessoirenummer='" + accessoire.Accessoirenummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            return accessoire;
        }

        public void ToevoegenAccessoire(Accessoire accessoire)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "INSERT INTO accessoire (Naam, Huurprijs) VALUE ('" + accessoire.Naam + "', '" + accessoire.Huurprijs + "')";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
        }
        
        public void VerwijderenAccessoire(Accessoire accessoire)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "DELETE FROM accessoire WHERE accessoirenummer='" + accessoire.Accessoirenummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
        }


        public void Close()
        {
            if (connection != null)
            {
                connection.Close();
                connection = null;
            }
        }

    }
}
