﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace Bakfiets
{
    public class DBConnectie
    {

        public List<Klant> GetKlanten()
        {
            List<Klant> klanten = new List<Klant>();

            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfiets;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("SELECT * FROM klanten", conn);
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                Klant klant = new Klant();
                klant.id = Convert.ToInt32(reader["id"]);
                klant.Naam = Convert.ToString(reader["Naam"]);
                klant.Straat = Convert.ToString(reader["Straat"]);
                klant.Postcode = Convert.ToString(reader["Postcode"]);
                klanten.Add(klant);
            }

            conn.Close();

            return klanten;
        }

        public List<Bakfiets> GetBakfietsen()
        {
            List<Bakfiets> bakfietsen = new List<Bakfiets>();

            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfiets;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("SELECT * FROM bakfietsen", conn);
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                Bakfiets bakfiets = new Bakfiets();
                bakfiets.id = Convert.ToInt32(reader["id"]);
                bakfiets.Naam = Convert.ToString(reader["Naam"]);
                bakfiets.Prijs = Convert.ToInt32(reader["Prijs"]);
                bakfietsen.Add(bakfiets);
            }

            conn.Close();

            return bakfietsen;
        }

        public List<Accessoires> GetAccessoires()
        {
            List<Accessoires> accessoires = new List<Accessoires>();

            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfiets;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("SELECT * FROM accessoires", conn);
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                Accessoires acc = new Accessoires();
                acc.id = Convert.ToInt32(reader["id"]);
                acc.Naam = Convert.ToString(reader["Naam"]);
                acc.Prijs = Convert.ToInt32(reader["Prijs"]);
                accessoires.Add(acc);
            }

            conn.Close();

            return accessoires;
        }

        public List<Medewerker> GetMederwerkers()
        {
            List<Medewerker> medewerkers = new List<Medewerker>();

            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfiets;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            MySqlCommand comm = new MySqlCommand("SELECT * FROM medewerkers", conn);
            MySqlDataReader reader = comm.ExecuteReader();
            while (reader.Read())
            {
                Medewerker medewerker = new Medewerker();
                medewerker.id = Convert.ToInt32(reader["id"]);
                medewerker.Naam = Convert.ToString(reader["Naam"]);
                medewerker.Wachtwoord = Convert.ToInt32(reader["Wachtword"]);
                medewerkers.Add(medewerker);
            }

            conn.Close();

            return medewerkers;
        }

        //CONNECTIE MAKEN MET VERHUUR! <<<------ 


    }
}
