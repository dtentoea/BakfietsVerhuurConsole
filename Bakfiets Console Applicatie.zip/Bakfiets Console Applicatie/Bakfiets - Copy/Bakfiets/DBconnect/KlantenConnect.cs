﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;


namespace Bakfiets
{
    public class KlantenConnect
    {
        private string connString = string.Format("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
        private MySqlConnection connection = null;

        public bool IsConnect()
        {
            if (connection == null)
            {
                connection = new MySqlConnection(connString);
                connection.Open();
            }
            return true;
        }

        public List<Klant> GetKlanten()
        {
            List<Klant> klantenLijst = new List<Klant>();
            if (IsConnect())
            {
                string query = "SELECT * FROM klant";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int klantnummer = reader.GetInt32("klantnummer");
                    string naam = reader.GetString("naam");
                    string voornaam = reader.GetString("voornaam");
                    string postcode = reader.GetString("postcode");
                    int huisnummer = reader.GetInt32("huisnummer");
                    string huisnummer_toevoeging = reader.GetString("huisnummer_toevoeging");
                    string opmerkingen = reader.GetString("opmerkingen");
                    Klant klant = new Klant(klantnummer, naam, voornaam, postcode, huisnummer, huisnummer_toevoeging, opmerkingen);
                    klantenLijst.Add(klant);
                }
                reader.Close();
                Close();
            }
            return klantenLijst;
        }

        public Klant GetKlant(int nummer)
        {
            Klant klant = null;
            if (IsConnect())
            {
                MySqlCommand cmd = new MySqlCommand("SELECT FROM klant" + "WHERE klantnummer=@klantnummer", connection);
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@klantnummer", nummer);
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    int klantnummer = reader.GetInt32("klantnummer");
                    string naam = reader.GetString("naam");
                    string voornaam = reader.GetString("voornaam");
                    string postcode = reader.GetString("postcode");
                    int huisnummer = reader.GetInt32("huisnummer");
                    string huisnummer_toevoeging = reader.GetString("huisnummer_toevoeging");
                    string opmerkingen = reader.GetString("opmerkingen");
                    klant = new Klant(klantnummer, naam, voornaam, postcode, huisnummer, huisnummer_toevoeging, opmerkingen);
                }
                reader.Close();
                Close();
            }
            return klant;
        }

        public Klant AanpassenKlant(Klant klant)
        {

            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "UPDATE klant SET naam = '" + klant.Naam + "', voornaam = '" + klant.Voornaam + "', postcode = '" + klant.Postcode + "', huisnummer = '" + klant.Huisnummer + "', huisnummer_toevoeging = '" + klant.Huisnummer_toevoeging + "', opmerkingen = '" + klant.Opmerkingen + "' WHERE klantnummer='" + klant.Klantnummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            return klant;
        }

        public void ToevoegenKlant(Klant Klant)
        {
            if (IsConnect())
            {
                string sqlStatement = "INSERT INTO klant (Klantnummer, Naam, Voornaam, Postcode, Huisnummer, Huisnummer_toevoeging, Opmerkingen) VALUE ('" + Klant.Klantnummer + "', '" + Klant.Naam + "', '" + Klant.Voornaam + "', '" + Klant.Postcode + "', '" + Klant.Huisnummer + "', '" + Klant.Huisnummer_toevoeging + "', '" + Klant.Opmerkingen + "') ";
                MySqlCommand cmd = new MySqlCommand(sqlStatement, connection);
                cmd.Parameters.AddWithValue("@klantnummer", Klant.Klantnummer);
                cmd.Parameters.AddWithValue("@naam", Klant.Naam);
                cmd.Parameters.AddWithValue("@voornaam", Klant.Voornaam);
                cmd.Parameters.AddWithValue("@postcode", Klant.Postcode);
                cmd.Parameters.AddWithValue("@huisnummer", Klant.Huisnummer);
                cmd.Parameters.AddWithValue("@huisnummer_toevoeging", Klant.Huisnummer_toevoeging);
                cmd.Parameters.AddWithValue("@opmerkingen", Klant.Opmerkingen);
                cmd.Prepare();
                cmd.ExecuteNonQuery();
                Close();
            }

        }


        public void VerwijderKlant(Klant klant)
        {

            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "DELETE FROM klant WHERE klantnummer='" + klant.Klantnummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();


        }



        public void Close()
        {
            if (connection != null)
            {
                connection.Close();
                connection = null;
            }
        }


    }
}
