﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;


namespace Bakfiets
{
    public class VerhuurConnect
    {
        private string connString = string.Format("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
        private MySqlConnection connection = null;

        public int correct;

        public bool IsConnect()
        {
            if (connection == null)
            {
                connection = new MySqlConnection(connString);
                connection.Open();
            }
            return true;
        }

        public List<Verhuur> GetVerhuringen()
        {
            List<Verhuur> verhuurLijst = new List<Verhuur>();
            if (IsConnect())
            {
                string query = "SELECT v.*, k.* FROM verhuur v INNER JOIN klant k ON k.klantnummer = v.klantnummer ";
                //string query = "SELECT v.*, k.* FROM verhuur v CROSS JOIN klant k";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int verhuurnummer = reader.GetInt32("verhuurnummer");
                    DateTime verhuurdatum = reader.GetDateTime("verhuurdatum");
                    int bakfietsnummer = reader.GetInt32("bakfietsnummer");
                    Bakfiets bNummer = new Bakfiets(bakfietsnummer);
                    int aantal_dagen = reader.GetInt32("aantal_dagen");
                    decimal huurprijstotaal = reader.GetDecimal("huurprijstotaal");
                    int klantnummer = reader.GetInt32("klantnummer");
                    string naam = reader.GetString("naam");
                    string voornaam = reader.GetString("voornaam");
                    string postcode = reader.GetString("postcode");
                    int huisnummer = reader.GetInt32("huisnummer");
                    string huisnummer_toevoeging = reader.GetString("huisnummer_toevoeging");
                    string opmerkingen = reader.GetString("opmerkingen");
                    Klant kNummer = new Klant(klantnummer, naam, voornaam, postcode, huisnummer, huisnummer_toevoeging, opmerkingen);
                    int medewerkernummer = reader.GetInt32("verhuurder");
                    Medewerker medewerker = new Medewerker(medewerkernummer);
                    medewerker.Achternaam = reader.GetString("naam");
                    Verhuur verhuur = new Verhuur(verhuurnummer, verhuurdatum, bNummer, aantal_dagen, huurprijstotaal, kNummer, medewerker);
                    verhuurLijst.Add(verhuur);
                }
                reader.Close();
                Close();
            }
            return verhuurLijst;
        }


        public Verhuur GetVerhuur(int nummer)
        {
            Verhuur verhuur = null;
            if (IsConnect())
            {
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM verhuur" + "WHERE verhuurnummer=@verhuurnummer", connection);
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@verhuurnummer", nummer);
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    int verhuurnummer = reader.GetInt32("verhuurnummer");
                    DateTime verhuurdatum = reader.GetDateTime("verhuurdatum");
                    int bakfietsnummer = reader.GetInt32("bakfietsnummer");
                    Bakfiets bNummer = new Bakfiets(bakfietsnummer);
                    int aantal_dagen = reader.GetInt32("aantal_dagen");
                    decimal huurprijstotaal = reader.GetDecimal("huurprijstotaal");
                    int klantnummer = reader.GetInt32("klantnummer");
                    Klant kNummer = new Klant(klantnummer);
                    int medewerkernummer = reader.GetInt32("verhuurder");
                    Medewerker mNummer = new Medewerker(medewerkernummer);
                    verhuur = new Verhuur(verhuurnummer, verhuurdatum, bNummer, aantal_dagen, huurprijstotaal, kNummer, mNummer);
                }
                reader.Close();
                Close();
            }
            return verhuur;
        }

        public void ToevoegenVerhuur(Verhuur verhuur)
        {
            if (IsConnect())
            {
                string sqlStatement = "INSERT INTO verhuur (verhuurnummer, verhuurdatum, bakfietsnummer, aantal_dagen, huurprijstotaal, klantnummer, verhuurder) VALUE ('" + verhuur.Verhuurnummer + "', '" + verhuur.Verhuurdatum.ToString("yyyy-MM-dd") + "', '" + verhuur.Bakfietsnummer.Bakfietsnummer + "', '" + verhuur.Aantal_dagen + "', '" + verhuur.Huurprijstotaal + "', '" + verhuur.Klantnummer.Klantnummer + "', '" + verhuur.Medewerkernummer.Medewerkernummer + "') ";
                MySqlCommand cmd = new MySqlCommand(sqlStatement, connection);
                cmd.Parameters.AddWithValue("@verhuurnummer", verhuur.Verhuurnummer);
                cmd.Parameters.AddWithValue("@verhuurdatum", verhuur.Verhuurdatum.ToString("yyyy-MM-dd"));
                cmd.Parameters.AddWithValue("@bakfietsnummer", verhuur.Bakfietsnummer.Bakfietsnummer);
                cmd.Parameters.AddWithValue("@aantal_dagen", verhuur.Aantal_dagen);
                cmd.Parameters.AddWithValue("@huurprijstotaal", verhuur.Huurprijstotaal);
                cmd.Parameters.AddWithValue("@klantnummer", verhuur.Klantnummer.Klantnummer);
                cmd.Parameters.AddWithValue("@verhuurder", verhuur.Medewerkernummer.Medewerkernummer);
                cmd.Prepare();
                cmd.ExecuteNonQuery();
                Close();
            }

        }


            public void VerwijderenVerhuur(Verhuur verhuur)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "DELETE FROM verhuur WHERE accessoirenummer='" + verhuur.Verhuurnummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
        }



        public void Close()
        {
            if (connection != null)
            {
                connection.Close();
                connection = null;
            }
        }


    }
}
