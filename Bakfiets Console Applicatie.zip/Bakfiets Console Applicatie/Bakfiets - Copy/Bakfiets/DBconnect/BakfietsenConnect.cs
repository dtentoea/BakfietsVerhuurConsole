﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;


namespace Bakfiets
{
    public class BakfietsenConnect
    {
        private string connString = string.Format("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
        private MySqlConnection connection = null;

        public bool IsConnect()
        {
            if (connection == null)
            {
                connection = new MySqlConnection(connString);
                connection.Open();
            }
            return true;
        }

        public List<Bakfiets> GetBakfietsen()
        {
            List<Bakfiets> bakfietsenLijst = new List<Bakfiets>();
            if (IsConnect())
            {
                string query = "SELECT * FROM bakfiets";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int bakfietsnummer = reader.GetInt32("bakfietsnummer");
                    string naam = reader.GetString("naam");
                    string type = reader.GetString("type");
                    decimal huurprijs = reader.GetDecimal("huurprijs");
                    int aantal = reader.GetInt32("aantal");
                    int aantal_verhuurd = reader.GetInt32("aantal_verhuurd");
                    Bakfiets bakfiets = new Bakfiets(bakfietsnummer, naam, type, huurprijs, aantal, aantal_verhuurd);
                    bakfietsenLijst.Add(bakfiets);
                }
                reader.Close();
                Close();
            }
            return bakfietsenLijst;
        }

        public Bakfiets GetBakfiets(int nummer)
        {
            
            Bakfiets bakfiets = null;
            if (IsConnect())
            {
                MySqlCommand cmd = new MySqlCommand(
                    "SELECT * FROM bakfiets ", connection);
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@bakfietsnummer", nummer);
                MySqlDataReader reader = cmd.ExecuteReader();

                for (int i = 0; i < nummer; i++)
                {
                    if (reader.Read())
                    {
                        int bakfietsnummer = reader.GetInt32("bakfietsnummer");
                        string naam = reader.GetString("naam");
                        string type = reader.GetString("type");
                        decimal huurprijs = reader.GetDecimal("huurprijs");
                        int aantal = reader.GetInt32("aantal");
                        int aantal_verhuurd = reader.GetInt32("aantal_verhuurd");
                        bakfiets = new Bakfiets(bakfietsnummer, naam, type, huurprijs, aantal, aantal_verhuurd);
                    }
                }
                
                reader.Close();
                Close();
            }
            return bakfiets;
        }

        public Bakfiets AanpassenBakfiets(Bakfiets bakfiets)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "UPDATE bakfiets SET naam = '" + bakfiets.Naam + "', type = '" + bakfiets.Type + "', huurprijs = '" + bakfiets.Huurprijs + "', aantal = '" + bakfiets.Aantal + "', aantal_verhuurd = '" + bakfiets.Aantal_verhuurd + "'  WHERE bakfietsnummer='" + bakfiets.Bakfietsnummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            return bakfiets;
        }

        public void ToevoegenBakfiets(Bakfiets bakfiets)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "INSERT INTO bakfiets (naam, type, huurprijs, aantal, aantal_verhuurd) VALUE ('" + bakfiets.Naam + "', '" + bakfiets.Type + "', '" + bakfiets.Huurprijs + "', '" + bakfiets.Aantal + "', '" + bakfiets.Aantal_verhuurd + "')";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
        }



        public void VerwijderenBakfiets(Bakfiets bakfiets)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "DELETE FROM bakfiets WHERE bakfietsnummer='" + bakfiets.Bakfietsnummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
        }



        public void Close()
        {
            if (connection != null)
            {
                connection.Close();
                connection = null;
            }
        }

    }
}
