﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;


namespace Bakfiets
{


    public class MedewerkersConnect
    {



        private string connString = string.Format("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
        private MySqlConnection connection = null;

        public bool IsConnect()
        {
            if (connection == null)
            {
                connection = new MySqlConnection(connString);
                connection.Open();
            }
            return true;
        }

        public List<Medewerker> GetMedewerkers()
        {
            List<Medewerker> medewerkerLijst = new List<Medewerker>();
            if (IsConnect())
            {
                string query = "SELECT * FROM medewerker";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int medewerkernummer = reader.GetInt32("medewerkernummer");
                    string achternaam = reader.GetString("achternaam");
                    string voornaam = reader.GetString("voornaam");
                    DateTime datum_in_dienst = reader.GetDateTime("datum_in_dienst");
                    Medewerker medewerker = new Medewerker(medewerkernummer, achternaam, voornaam, datum_in_dienst);
                    medewerkerLijst.Add(medewerker);
                }
                reader.Close();
                Close();
            }
            return medewerkerLijst;
        }

        public Medewerker GetMedewerker(int nummer)
        {
            Medewerker medewerker = null;
            if (IsConnect())
            {
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM medewerker" + "WHERE medewerkernummer=@medewerkernummer", connection);
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@medewerkernummer", nummer);
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    int medewerkernummer = reader.GetInt32("medewerkernummer");
                    string achternaam = reader.GetString("achternaam");
                    string voornaam = reader.GetString("voornaam");
                    DateTime datum_in_dienst = reader.GetDateTime("datum_in_dienst");
                    medewerker = new Medewerker(medewerkernummer, achternaam, voornaam, datum_in_dienst);
                }
                reader.Close();
                Close();
            }
            return medewerker;
        }

        public Medewerker AanpassenMedewerker(Medewerker medewerker)   
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "UPDATE medewerker SET achternaam = '" + medewerker.Achternaam + "', voornaam = '" + medewerker.Voornaam + "', datum_in_dienst = '" + medewerker.Datum_in_dienst.ToString("yyyy-MM-dd") + "' WHERE medewerkernummer='" + medewerker.Medewerkernummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            return medewerker;
        }

        public void ToevoegenMedewerker(Medewerker medewerker)
        {
            if (IsConnect())
            {
                string sqlStatement = "INSERT INTO medewerker (medewerkernummer, Achternaam, Voornaam, Datum_in_dienst) VALUE ('" + medewerker.Medewerkernummer + "', '" + medewerker.Achternaam + "', '" + medewerker.Voornaam + "', '" + medewerker.Datum_in_dienst.ToString("yyyy-MM-dd") + "')";
                MySqlCommand cmd = new MySqlCommand(sqlStatement, connection);
                cmd.Parameters.AddWithValue("@medewerkernummer", medewerker.Medewerkernummer);
                cmd.Parameters.AddWithValue("@naam", medewerker.Achternaam);
                cmd.Parameters.AddWithValue("@voornaam", medewerker.Voornaam);
                cmd.Parameters.AddWithValue("@Datum_in_dienst", medewerker.Datum_in_dienst.ToString("yyyy-MM-dd"));
                cmd.Prepare();
                cmd.ExecuteNonQuery();
                Close();
            }

        }
        public void VerwijderenMedewerker(Medewerker medewerker)
        {
            MySqlConnection conn = new MySqlConnection("Server=localhost;Database=bakfietsnieuw;Uid=root;Pwd=Brandean@01;");
            conn.Open();
            string sqlStatement = "DELETE FROM medewerker WHERE medewerkernummer='" + medewerker.Medewerkernummer + "'";
            MySqlCommand comm = new MySqlCommand(sqlStatement, conn);
            comm.ExecuteNonQuery();
            conn.Close();
        }


        public Medewerker Login(string userName, DateTime password)
        {
            Medewerker medewerker = null;

            if (IsConnect())
            {
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM medewerker WHERE achternaam= '" + userName + "' and datum_in_dienst= '" + password.ToString("yyyy-MM-dd") + "' ", connection);
                cmd.Prepare();
                cmd.Parameters.AddWithValue("@achternaam", userName);
                cmd.Parameters.AddWithValue("@datum_in_dienst", password.ToString("yyyy-MM-dd"));
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int medewerkernummer = reader.GetInt32("medewerkernummer");
                    string achternaam = reader.GetString("achternaam");
                    string voornaam = reader.GetString("voornaam");
                    DateTime datum_in_dienst = reader.GetDateTime("datum_in_dienst");
                    medewerker = new Medewerker(medewerkernummer, achternaam, voornaam, datum_in_dienst);

                    if (userName == achternaam && password == datum_in_dienst)
                    {
                        reader.Close();
                        Close();
                        break;
                    }

                }

                reader.Close();
                Close();
            }
            return medewerker;
        }






        public void Close()
        {
            if (connection != null)
            {
                connection.Close();
                connection = null;
            }
        }

    }
}
